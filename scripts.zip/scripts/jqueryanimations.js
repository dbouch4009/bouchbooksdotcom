//JQuery
$(document).ready(function(){
    $('.hype-carousel').addClass('animated fadeInLeft');
});